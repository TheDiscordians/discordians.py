from .client import DiscordiansClient
__author__ = "NightShade256"
__version__="1.0.0"
__license__ = "MIT"