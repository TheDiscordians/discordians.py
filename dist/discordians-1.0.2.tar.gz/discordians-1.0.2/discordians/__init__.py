from .client import DiscordiansClient
__author__ = "NightShade256"
__version__="1.0.1"
__license__ = "MIT"